package catalogue;

import clients.customer.AuthManager;

import java.io.Serializable;
import java.util.Collections;

/**
 * Improved version of BetterBasket with authentication restriction.
 *
 * @author  Reina Yembe
 * @version 1.1
 */
public class BetterBasket extends Basket implements Serializable {
  private AuthManager authManager;
  private String loggedInUser;

  /**
   * Constructor with authentication
   * @param authManager Instance of AuthManager to verify authentication
   * @param loggedInUser The currently logged-in user
   */
  public BetterBasket(AuthManager authManager, String loggedInUser) {
    this.authManager = authManager;
    this.loggedInUser = loggedInUser;
  }

  /**
   * Checks if the user is authenticated before adding products to the basket.
   * @param pr The product to be added
   * @return true if the product is added, false if access is denied
   */
  @Override
  public boolean add(Product pr) {
    if (!isAuthenticated()) {
      System.out.println("Access Denied! Please log in to add items to your basket.");
      return false;
    }

    for (Product prInList : this) {
      if (prInList.getProductNum().equals(pr.getProductNum())) {
        int quantity = pr.getQuantity() + prInList.getQuantity();
        prInList.setQuantity(quantity);
        return true;
      }
    }

    super.add(pr);
    Collections.sort(this);
    return true;
  }

  /**
   * Checks if the user is authenticated.
   * @return true if the user is logged in, false otherwise.
   */
  private boolean isAuthenticated() {
    return loggedInUser != null && authManager.isUserLoggedIn(loggedInUser);
  }
}
