package clients.cashier;

import catalogue.*;
import clients.customer.AuthManager;
import middle.MiddleFactory;
import middle.Names;
import middle.RemoteMiddleFactory;

import javax.swing.*;
import java.util.Scanner;

/**
 * The standalone Cashier Client with authentication.
 */
public class CashierClient {
    public static void main(String args[]) {
        String stockURL = args.length < 1 ? Names.STOCK_RW : args[0];
        String orderURL = args.length < 2 ? Names.ORDER : args[1];

        RemoteMiddleFactory mrf = new RemoteMiddleFactory();
        mrf.setStockRWInfo(stockURL);
        mrf.setOrderInfo(orderURL);

        //  Authentication before GUI loads
        AuthManager auth = new AuthManager();
        Scanner scanner = new Scanner(System.in);

        String username = null;
        while (username == null) {
            System.out.println("\nCASHIER LOGIN");
            System.out.println("1. Login");
            System.out.println("2. Exit");
            System.out.print("Choose option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // consume newline

            if (option == 2) {
                System.out.println("Exiting Cashier...");
                return;
            }

            System.out.print("Username: ");
            String userInput = scanner.nextLine();

            System.out.print("Password: ");
            String passInput = scanner.nextLine();

            if (auth.loginUser(userInput, passInput)) {
                System.out.println("Login successful!");
                username = userInput;
            } else {
                System.out.println("Invalid login. Try again.");
            }
        }

        displayGUI(mrf, auth, username);
    }

    //  Updated to accept AuthManager and username
    private static void displayGUI(MiddleFactory mf, AuthManager auth, String username) {
        JFrame window = new JFrame();
        window.setTitle("Cashier Client (MVC RMI)");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        CashierModel model = new CashierModel(mf, auth, username);
        CashierView view = new CashierView(window, mf, 0, 0);
        CashierController cont = new CashierController(model, view);
        view.setController(cont);

        model.addObserver(view);
        window.setVisible(true);
        model.askForUpdate();
    }
}
