package clients;

import clients.backDoor.BackDoorController;
import clients.backDoor.BackDoorModel;
import clients.backDoor.BackDoorView;
import clients.cashier.CashierController;
import clients.cashier.CashierModel;
import clients.cashier.CashierView;
import clients.customer.AuthManager;
import clients.customer.CustomerController;
import clients.customer.CustomerModel;
import clients.customer.CustomerView;
import clients.packing.PackingController;
import clients.packing.PackingModel;
import clients.packing.PackingView;
import middle.LocalMiddleFactory;
import middle.MiddleFactory;

import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

/**
 * Starts all the clients (user interface) as a single application.
 * Good for testing the system using a single application.
 */
public class Main {
  private static AuthManager authManager = new AuthManager(); //  Keep only this instance

  public static void main(String[] args) {
    String loggedInUser = authenticateUser(authManager); //  Use the global `authManager`

    if (loggedInUser == null) {
      System.out.println("Exiting MiniStore...");
      return;
    }

    System.out.println("Login successful! Welcome, " + loggedInUser);
    new Main().begin(loggedInUser); // Launch the store system after successful authentication
  }

  /**
   * Authentication method to ensure only registered users can access the system.
   */
  private static String authenticateUser(AuthManager authManager) { //  Use the passed authManager
    Scanner scanner = new Scanner(System.in);
    String username = null;

    System.out.println("Welcome to MiniStore!");

    while (username == null) {
      System.out.println("\n1. Register\n2. Login\n3. Exit");
      System.out.print("Choose an option: ");
      int choice = scanner.nextInt();
      scanner.nextLine(); // Consume newline

      if (choice == 3) {
        scanner.close();
        return null; // Exit if user chooses to leave
      }

      System.out.print("Enter username: ");
      String inputUsername = scanner.nextLine();

      System.out.print("Enter password: ");
      String inputPassword = scanner.nextLine();

      if (choice == 1) {
        if (authManager.registerUser(inputUsername, inputPassword)) {
          System.out.println("Registration successful! Please log in.");
        } else {
          System.out.println("Username already exists. Try again.");
        }
      } else if (choice == 2) {
        if (authManager.loginUser(inputUsername, inputPassword)) {
          username = inputUsername;
        } else {
          System.out.println("Invalid credentials. Try again.");
        }
      }
    }

    scanner.close();
    return username; // Return the authenticated username
  }

  /**
   * Starts the system
   */
  public void begin(String loggedInUser) {
    MiddleFactory mlf = new LocalMiddleFactory();
    startCustomerGUI_MVC(mlf, loggedInUser);
    startCashierGUI_MVC(mlf, loggedInUser);
    startPackingGUI_MVC(mlf);
    startBackDoorGUI_MVC(mlf);
  }

  /**
   * Starts the Customer client for searching products.
   */
  public void startCustomerGUI_MVC(MiddleFactory mlf, String loggedInUser) {
    JFrame window = new JFrame();
    window.setTitle("Customer Client MVC");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Dimension pos = PosOnScrn.getPos();

    //  Pass authentication parameters correctly
    CustomerModel model = new CustomerModel(mlf, authManager, loggedInUser);
    CustomerView view = new CustomerView(window, mlf, pos.width, pos.height);
    CustomerController cont = new CustomerController(model, view);
    view.setController(cont);

    model.addObserver(view);
    window.setVisible(true);
  }

  /**
   * Starts the Cashier client for checking stock and purchasing products.
   */
  public void startCashierGUI_MVC(MiddleFactory mlf, String loggedInUser) {
    JFrame window = new JFrame();
    window.setTitle("Cashier Client MVC");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Dimension pos = PosOnScrn.getPos();

    CashierModel model = new CashierModel(mlf, authManager, loggedInUser);
    CashierView view = new CashierView(window, mlf, pos.width, pos.height);
    CashierController cont = new CashierController(model, view);
    view.setController(cont);

    model.addObserver(view);
    window.setVisible(true);
    model.askForUpdate();
  }

  /**
   * Starts the Packing client for warehouse staff to pack customer orders.
   */
  public void startPackingGUI_MVC(MiddleFactory mlf) {
    JFrame window = new JFrame();
    window.setTitle("Packing Client MVC");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Dimension pos = PosOnScrn.getPos();

    PackingModel model = new PackingModel(mlf);
    PackingView view = new PackingView(window, mlf, pos.width, pos.height);
    PackingController cont = new PackingController(model, view);
    view.setController(cont);

    model.addObserver(view);
    window.setVisible(true);
  }

  /**
   * Starts the BackDoor client for store staff to check and update stock.
   */
  public void startBackDoorGUI_MVC(MiddleFactory mlf) {
    JFrame window = new JFrame();
    window.setTitle("BackDoor Client MVC");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    Dimension pos = PosOnScrn.getPos();

    BackDoorModel model = new BackDoorModel(mlf);
    BackDoorView view = new BackDoorView(window, mlf, pos.width, pos.height);
    BackDoorController cont = new BackDoorController(model, view);
    view.setController(cont);

    model.addObserver(view);
    window.setVisible(true);
  }
}
