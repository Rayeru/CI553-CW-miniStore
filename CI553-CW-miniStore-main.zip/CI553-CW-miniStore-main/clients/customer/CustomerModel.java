package clients.customer;

import catalogue.Basket;
import catalogue.Product;
import debug.DEBUG;
import middle.MiddleFactory;
import middle.OrderProcessing;
import middle.StockException;
import middle.StockReader;

import javax.swing.*;
import java.util.Observable;

/**
 * Implements the Model of the customer client with authentication.
 */
public class CustomerModel extends Observable {
  private Product theProduct = null;  // Current product
  private Basket theBasket = null;    // Bought items
  private String pn = "";             // Product being processed

  private StockReader theStock = null;
  private OrderProcessing theOrder = null;
  private ImageIcon thePic = null;

  private AuthManager authManager;   // Authentication Manager
  private String loggedInUser;       // Track logged-in user

  /**
   * Construct the model of the Customer with authentication
   * @param mf The factory to create the connection objects
   * @param authManager Authentication Manager instance
   * @param username The username of the logged-in user
   */
  public CustomerModel(MiddleFactory mf, AuthManager authManager, String username) {
    this.authManager = authManager;
    this.loggedInUser = username;

    try {
      theStock = mf.makeStockReader();  // Database access
    } catch (Exception e) {
      DEBUG.error("CustomerModel.constructor\nDatabase not created?\n%s\n", e.getMessage());
    }

    if (isAuthenticated()) {
      theBasket = makeBasket();  // Initial Basket (only if authenticated)
    } else {
      System.out.println("Access Denied! You must log in to use the shopping cart.");
    }
  }

  public CustomerModel(MiddleFactory mf) {
  }

  /**
   * Check if the user is authenticated
   * @return true if authenticated, false otherwise
   */
  private boolean isAuthenticated() {
    return loggedInUser != null && authManager.isUserLoggedIn(loggedInUser);
  }

  /**
   * Return the Basket of products (only if authenticated)
   * @return the basket of products
   */
  public Basket getBasket() {
    if (!isAuthenticated()) {
      System.out.println("Access Denied! Please log in to access your basket.");
      return null;
    }
    return theBasket;
  }

  /**
   * Check if the product is in Stock (only if authenticated)
   * @param productNum The product number
   */
  public void doCheck(String productNum) {
    if (!isAuthenticated()) {
      setChanged(); notifyObservers("Access Denied! Please log in.");
      return;
    }

    theBasket.clear();  // Clear list
    String theAction = "";
    pn = productNum.trim();  // Product no.
    int amount = 1;  // & quantity

    try {
      if (theStock.exists(pn)) {  // Stock Exists?
        Product pr = theStock.getDetails(pn);
        if (pr.getQuantity() >= amount) {
          theAction = String.format("%s : %7.2f (%2d) ", pr.getDescription(), pr.getPrice(), pr.getQuantity());
          pr.setQuantity(amount);  // Require 1
          theBasket.add(pr);  // Add to basket
          thePic = theStock.getImage(pn);  // product
        } else {
          theAction = pr.getDescription() + " not in stock";
        }
      } else {
        theAction = "Unknown product number " + pn;
      }
    } catch (StockException e) {
      DEBUG.error("CustomerClient.doCheck()\n%s", e.getMessage());
    }
    setChanged(); notifyObservers(theAction);
  }

  /**
   * Clear the products from the basket (only if authenticated)
   */
  public void doClear() {
    if (!isAuthenticated()) {
      setChanged(); notifyObservers("Access Denied! Please log in.");
      return;
    }

    String theAction = "";
    theBasket.clear();  // Clear list
    theAction = "Enter Product Number";  // Set display
    thePic = null;  // No picture
    setChanged(); notifyObservers(theAction);
  }

  /**
   * Return a picture of the product
   * @return An instance of an ImageIcon
   */
  public ImageIcon getPicture() {
    return thePic;
  }

  /**
   * Ask for update of view called at start
   */
  private void askForUpdate() {
    setChanged(); notifyObservers("START only"); // Notify
  }

  /**
   * Make a new Basket
   * @return an instance of a new Basket
   */
  protected Basket makeBasket() {
    return new Basket();
  }
}
