package clients.customer;

import clients.customer.User;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class AuthManager {
    private static final String FILE_PATH = "users.dat"; // Name of the file where users are stored
    private Map<String, User> users;
    private String loggedInUser = null; // Track currently logged-in user

    public AuthManager() {
        users = loadUsers();
    }

    // Load users from file
    private Map<String, User> loadUsers() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            return (Map<String, User>) ois.readObject();
        } catch (Exception e) {
            return new HashMap<>();  // Return an empty user list if file doesn't exist
        }
    }

    // Save users to file
    private void saveUsers() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Register a new user
    public boolean registerUser(String username, String password) {
        if (users.containsKey(username)) {
            return false; // Username already exists
        }
        users.put(username, new User(username, password));
        saveUsers();
        return true;
    }

    // Authenticate user
    public boolean loginUser(String username, String password) {
        User user = users.get(username);
        if (user != null && user.checkPassword(password)) {
            loggedInUser = username; // Store logged-in user
            return true;
        }
        return false;
    }

    // **New Method: Check if user is logged in**
    public boolean isUserLoggedIn(String username) {
        return loggedInUser != null && loggedInUser.equals(username);
    }

    // **New Method: Log out the current user**
    public void logoutUser() {
        loggedInUser = null;
    }
}
