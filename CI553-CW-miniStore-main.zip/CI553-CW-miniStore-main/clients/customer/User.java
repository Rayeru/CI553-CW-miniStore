package clients.customer;

import java.io.Serializable;

public class User implements Serializable {
    private String username;
    private String password;

    public User(String username, String password) {
        this.username = username; // initializes a user with a given username
        this.password = password; // initializes a user with a given password
    }

    public String getUsername() {
        return username;
    }

    public boolean checkPassword(String inputPassword) { // compares the input with the stored passwords
        return this.password.equals(inputPassword); // Plain-text storage
    }
}

